import { DataSet } from 'choerodon-ui/pro';

/**
 * 本地化多语言文本
 */
export function getIntlMeaning(meaning) {
  if (!meaning || typeof meaning === 'string') {
    return meaning;
  }
  const { language } = window.dvaApp._store.getState().global || {};
  return language in meaning ? meaning[language] : meaning[Object.keys(meaning)[0]];
}

export function createOptionDS(options) {
  return new DataSet({
    paging: false,
    data: options.map(({ value, meaning }) => ({
      value,
      meaning: getIntlMeaning(meaning),
    })),
  });
}
