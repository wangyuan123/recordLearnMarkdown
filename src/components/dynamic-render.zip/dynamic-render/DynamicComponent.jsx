import React, { cloneElement, useMemo, useEffect } from 'react';
import { toJS } from 'mobx';
import { isArray, isString, isObject } from 'lodash';
import { observer } from 'mobx-react-lite';
import { DataSet } from 'choerodon-ui/pro';
import { FieldType } from 'choerodon-ui/dataset/data-set/enum';
import { ComponentNames, ComponentMap } from './types';
import { createOptionDS } from './utils';

const LOCAL_FIELD_NAME = '__local_field__';

const DEFAULT_VALUE_FIELD = 'value';

const createLocalDSProps = (props) => {
  const {
    componentType,
    lookupCode,
    optionList,
    optionCode,
    valueField,
    textField,
    isRequired,
  } = props;

  // lov为对象，下拉选项为字符串
  const fieldType = [ComponentNames.LOV, ComponentNames.LOV_MULTIPLE].includes(componentType)
    ? FieldType.object
    : FieldType.string;

  // 值集视图编码
  const lovCode = optionCode;

  // 下拉选项列表
  const options = optionList && createOptionDS(optionList);

  return {
    autoCreate: false,
    fields: [
      {
        name: LOCAL_FIELD_NAME,
        type: fieldType,
        lookupCode,
        lovCode,
        options,
        valueField,
        textField,
        required: isRequired,
      },
    ],
  };
};

const translateToInnerValue = (
  outerValue,
  valueType,
  valueField,
) => {
  if (valueType === 'object') {
    return outerValue;
  }
  if (isArray(outerValue)) {
    return outerValue.map((item) => ({ [valueField]: item }));
  } else if (isString(outerValue)) {
    return { [valueField]: outerValue };
  } else {
    return null;
  }
};

const translateToOuterValue = (
  innerValue,
  valueType,
  valueField
) => {
  if (valueType === 'object') {
    return innerValue;
  }
  if (isArray(innerValue)) {
    return innerValue.map((item) => item[valueField]);
  } else if (isObject(innerValue)) {
    return innerValue[valueField];
  } else {
    return null;
  }
};

const isEqual = (value1, value2, valueField) => {
  if (!value1 && !value2) {
    return true;
  }
  if (isArray(value1) && isArray(value2)) {
    if (value1.length !== value2.length) {
      return false;
    }
    return value1.every((item, index) => isEqual(item, value2[index], valueField));
  }
  if (isObject(value1) && isObject(value2)) {
    return value1[valueField] === value2[valueField];
  }
  return value1 === value2;
};

const DynamicComponent = (props) => {
  const {
    componentType,
    optionList,
    lookupCode,
    optionCode,
    record,
    name,
    valueField,
    textField,
    lovValueType = 'object',
    isRequired,
    ...renderProps
  } = props;

  const localDs = useMemo(() => {
    const dsProps = createLocalDSProps({
      componentType,
      optionList,
      lookupCode,
      optionCode,
      valueField,
      textField,
      isRequired,
    });
    return new DataSet(dsProps);
  }, [componentType, optionList, lookupCode, optionCode, valueField, textField]);

  const isLov = [ComponentNames.LOV, ComponentNames.LOV_MULTIPLE].includes(componentType);

  const localValueField =
    localDs.getField(LOCAL_FIELD_NAME)?.get('valueField', localDs.current) || DEFAULT_VALUE_FIELD;
  record?.setState('localValueField', localValueField);
  record?.setState('localDsXz', localDs);

  // 初始化
  useEffect(() => {
    localDs.create({
      [LOCAL_FIELD_NAME]: isLov
        ? translateToInnerValue(toJS(record?.get(name)), lovValueType, localValueField)
        : toJS(record?.get(name)),
    });
    isRequired && localDs?.validate();
  }, [localDs]);

  // 写入
  useEffect(() => {
    const outerValue = toJS(record?.get(name));
    const innerValue = toJS(localDs.current?.get(LOCAL_FIELD_NAME));
    const newInnerValue = isLov
      ? translateToInnerValue(outerValue, lovValueType, localValueField)
      : outerValue;
    if (isEqual(newInnerValue, innerValue, localValueField)) {
      return;
    }
    localDs.current?.set(LOCAL_FIELD_NAME, newInnerValue);
  }, [localDs, isLov, localValueField, lovValueType, record?.get(name)]);

  // 抛出
  useEffect(() => {
    const listener = ({ value: innerValue }) => {
      const newOuterValue = isLov
        ? translateToOuterValue(innerValue, lovValueType, localValueField)
        : innerValue;
      const outerValue = toJS(record?.get(name));
      if (!record || !name || isEqual(outerValue, newOuterValue, localValueField)) {
        return;
      }
      record.set(name, newOuterValue);
    };
    localDs.addEventListener('update', listener);
    return () => {
      localDs.removeEventListener('update', listener);
    };
  }, [localDs, record, name, isLov, lovValueType, localValueField]);

  const component = ComponentMap[componentType];

  return cloneElement(component, {
    ...renderProps,
    name: LOCAL_FIELD_NAME,
    record: localDs.current,
    dataSet: localDs,
  });
};

export default observer(DynamicComponent);
