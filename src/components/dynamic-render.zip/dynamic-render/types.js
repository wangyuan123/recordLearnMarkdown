import React, { ReactElement, CSSProperties } from 'react';
import {
  // DataSet,
  TextField,
  NumberField,
  DatePicker,
  DateTimePicker,
  Select,
  Lov,
} from 'choerodon-ui/pro';
// import Record from 'choerodon-ui/pro/lib/data-set/Record';

export const ComponentNames = {
  TEXT_FIELD: 'TextField', // 文本框
  TEXT_FIELD_MULTIPLE: 'TextFieldMultiple', // 文本框多标签
  NUMBER_FIELD: 'NumberField', // 数字框
  NUMBER_FIELD_MULTIPLE: 'NumberFieldMultiple', // 数字框多标签
  NUMBER_FIELD_RANGE: 'NumberFieldRange', // 数字框范围
  DATE_PICKER: 'DatePicker', // 日期选择框
  DATE_PICKER_MULTIPLE: 'DatePickerMultiple', // 日期选择框多标签
  DATE_PICKER_RANGE: 'DatePickerRange', // 日期选择框范围
  DATE_TIME_PICKER: 'DateTimePicker', // 日期时间选择框
  DATE_TIME_PICKER_MULTIPLE: 'DateTimePickerMultiple', // 日期时间选择框多标签
  DATE_TIME_PICKER_RANGE: 'DateTimePickerRange', // 日期时间选择框范围
  SELECT: 'Select', // 下拉单选
  SELECT_MULTIPLE: 'SelectMultiple', // 下拉多选
  LOV: 'Lov', // LOV
  LOV_MULTIPLE: 'LovMultiple', // LOV多选
}

export const ComponentMap = {
  [ComponentNames.TEXT_FIELD]: <TextField />,
  [ComponentNames.TEXT_FIELD_MULTIPLE]: <TextField multiple />,
  [ComponentNames.NUMBER_FIELD]: <NumberField />,
  [ComponentNames.NUMBER_FIELD_MULTIPLE]: <NumberField multiple />,
  [ComponentNames.NUMBER_FIELD_RANGE]: <NumberField range />,
  [ComponentNames.DATE_PICKER]: <DatePicker />,
  [ComponentNames.DATE_PICKER_MULTIPLE]: <DatePicker multiple />,
  [ComponentNames.DATE_PICKER_RANGE]: <DatePicker range />,
  [ComponentNames.DATE_TIME_PICKER]: <DateTimePicker />,
  [ComponentNames.DATE_TIME_PICKER_MULTIPLE]: <DateTimePicker multiple />,
  [ComponentNames.DATE_TIME_PICKER_RANGE]: <DateTimePicker range />,
  [ComponentNames.SELECT]: <Select />,
  [ComponentNames.SELECT_MULTIPLE]: <Select multiple />,
  [ComponentNames.LOV]: <Lov />,
  [ComponentNames.LOV_MULTIPLE]: <Lov multiple />,
};

// 渲染配置
// export type RenderOptions = {
//   componentType: ComponentNames;
//   optionList?: ValueList; // 选项列表
//   lookupCode?: string; // 值集编码
//   optionType?: 'BUSINESS_OBJECT_OPTION' | 'LOV_VIEW'; // 视图来源 - hmde引用值列表 | hzero值集视图
//   optionCode?: string; // 引用值列表编码/值集视图编码
//   valueField?: string; // 当组件为 Select 和 LOV 时指定值字段，默认从lov配置获取
//   textField?: string; // 当组件为 Select 和 LOV 时指定文本字段，默认从lov配置获取
//   lovValueType?: 'string' | 'object'; // 当组件为 LOV 时指定返回的值类型，默认为object
//   isRequired?: boolean; // 用于选项类/lov类字段红框问题
// };

// 渲染传参
// export type RenderProps = {
//   name?: string;
//   record?: Record | null;
//   dataSet?: DataSet | null;
//   style?: CSSProperties;
//   disabled?: boolean;
//   placeholder?: string;
//   colSpan?: number;
// };
