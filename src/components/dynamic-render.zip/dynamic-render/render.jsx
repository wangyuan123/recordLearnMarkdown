import React, { cloneElement } from 'react';
import DynamicComponent from './DynamicComponent.jsx';
import { ComponentNames, ComponentMap } from './types';

export default function renderDynamicFormItem(
  renderOptions,
  renderProps
) {
  const renderComponent = () => {
    const { componentType } = renderOptions;
    const { name, record, dataSet } = renderProps;
    if (
      [
        ComponentNames.SELECT,
        ComponentNames.SELECT_MULTIPLE,
        ComponentNames.LOV,
        ComponentNames.LOV_MULTIPLE,
      ].includes(componentType)
    ) {
      return (
        <DynamicComponent
          {...renderOptions}
          {...renderProps}
          name={name}
          record={record}
          dataSet={dataSet}
        />
      );
    }
    if (
      [
        ComponentNames.NUMBER_FIELD_RANGE,
        ComponentNames.DATE_PICKER_RANGE,
        ComponentNames.DATE_TIME_PICKER_RANGE,
      ].includes(componentType)
    ) {
      record?.getField(name)?.set('range', true);
    } else {
      record?.getField(name)?.set('range', false);
    }
    const component = ComponentMap[componentType];
    return cloneElement(component, {
      ...renderProps,
      name,
      record,
      dataSet,
    });
  };
  return renderComponent();
}
