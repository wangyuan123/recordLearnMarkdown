## 渲染条件组件使用说明

### 功能描述
`dynamic-render` 封装了根据 `字段类型` + `操作符类型` 最终获取到 渲染组件类型, 外部只需要传入一定的参数, 所有的逻辑都封装在组件内部, 不需要去考虑渲染以及赋值的一些问题


### 入参- 渲染配置- RenderOptions

| 参数 | 说明 | 类型 | 是否必填 |
|:--------------|---------------------------|----------|---------|
|componentType|需要渲染的组件的类型|ComponentNames|是|
|optionList|选项列表(自定义值集数据)|array|否|
|lookupCode|值集编码|string|否|
|optionType|试图来源(hmde引用值列表 / hzero值集视图)|BUSINESS_OBJECT_OPTION / LOV_VIEW|string|
|optionCode|引用值列表编码/值集视图编码|string|否|
|valueField|当组件为 Select 和 LOV 时指定值字段，默认从lov配置获取|string|否|
|textField|当组件为 Select 和 LOV 时指定文本字段，默认从lov配置获取|string|否|
|lovValueType|当组件为 LOV 时指定返回的值类型，默认为object|string/object|否|
|isRequired|是否必填,用于选项类/lov类字段红框问题|boolean|否|



### 入参- 渲染传参- RenderProps

| 参数 | 说明 | 类型 | 是否必填 |
|:--------------|---------------------------|----------|---------|
|name|渲染字段|string|是|
|record|单条数据|Record|是|
|dataSet|数据源|DataSet|否|
|disabled|是否禁用|boolean|否|
|placeholder|lov值集空的展示文案|string|否|

### 基本用法
```tsx
/packages/hzero-front-hmde/src/businessComponents/CommonApi/Request/QueryFieldRow.tsx
```

### 注意事项

- lov回显问题, 如果涉及到lov回显, 需要传递 lovValueType为 object, 而且 数据传入/传出的时候 都是对象的形式, 外部需要特殊处理




